/**
 * 
 */
package com.viit.steganography;

import com.viit.steganography.ui.MainWindow;

/**
 * @author mtalaat
 *
 */
public class Main {

	/**
	 * @param args
	 */
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		new MainWindow().show();

	}

}
